# KAIZAS FIX BUG — OPEN JASA

Website statik untuk deployment ke Vercel.

## Deploy
1. Muat turun dan ekstrak ZIP ini.
2. Upload `index.html` ke root repository GitHub.
3. Import repository di https://vercel.com/new.
4. Pilih Framework Preset `Other`; kosongkan Build Command; Output Directory boleh ditetapkan kepada `.`.
5. Tekan Deploy.

## Sebelum diterbitkan
Cari `https://whatsapp.com/channel/` sebanyak dua kali dalam `index.html`, kemudian gantikan setiap pautan dengan URL sebenar Saluran WhatsApp 1 dan 2.
Nombor WhatsApp servis telah ditetapkan kepada 601118837488.
